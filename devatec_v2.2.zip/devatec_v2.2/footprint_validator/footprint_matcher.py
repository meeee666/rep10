
import os
import difflib

def find_best_footprint(component_name, library_path, top_n=3):
    """
    Busca los footprints más similares al nombre del componente dentro de una librería.
    Args:
        component_name (str): Nombre del componente como "ws2812-2020"
        library_path (str): Ruta a la carpeta de footprints
        top_n (int): Número de coincidencias a retornar
    Returns:
        List[Tuple[str, str]]: Lista de tuplas (nombre_archivo, ruta_completa)
    """
    footprint_files = []
    for root, _, files in os.walk(library_path):
        for file in files:
            if file.endswith(".kicad_mod"):
                filepath = os.path.join(root, file)
                footprint_files.append((file, filepath))

    filenames = [name for name, _ in footprint_files]
    matches = difflib.get_close_matches(component_name, filenames, n=top_n, cutoff=0.3)

    matched_results = [(name, path) for name, path in footprint_files if name in matches]

    return matched_results
