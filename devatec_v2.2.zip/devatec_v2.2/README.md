# Devatec KiCad Project Generator

Este proyecto automatiza el flujo para generar proyectos de KiCad con footprints locales, asegurando portabilidad y consistencia.  
Con este flujo, los archivos `.kicad_pcb` generados sólo dependen de los footprints copiados localmente a la carpeta del proyecto.

---

## Estructura del Proyecto

```
devatec_v2.1/
├── input.json                   # Archivo de entrada con la lista de componentes y footprints genéricos
├── run_all.py                   # Script principal de automatización (ejecuta todo el flujo)
├── output_project/
│   ├── resolved_input.json      # Archivo generado con las rutas absolutas de footprints locales
│   ├── output.kicad_pcb         # Archivo de proyecto KiCad generado
│   └── footprints/              # Footprints locales copiados usados en el diseño
├── footprint_validator/
│   └── footprint_matcher.py     # Lógica para encontrar footprints en la librería local
├── pcb_generator/
│   └── pcb_generator.py         # Lógica para generar el archivo KiCad a partir del JSON resuelto
└── ...
```

---

## Flujo de trabajo

1. **Coloca tus componentes en `input.json`**  
   Este archivo debe estar en la raíz del proyecto y tener la lista de componentes con nombres de footprints genéricos.

2. **Ejecuta el flujo automatizado:**
   ```bash
   python3 run_all.py
   ```

   Este script:
   - Lee el `input.json`
   - Busca los footprints reales en tu librería local (configurable en el script)
   - Copia solo los footprints utilizados a `output_project/footprints/`
   - Genera un nuevo JSON (`resolved_input.json`) con las rutas absolutas de los footprints locales
   - Genera el archivo de proyecto KiCad (`output.kicad_pcb`) usando solo los footprints locales

3. **Abre el proyecto en KiCad**
   - El archivo `.kicad_pcb` en `output_project/` usará exclusivamente los footprints copiados en `output_project/footprints/`.
   - Puedes compartir la carpeta `output_project/` y será completamente portable.

---

## Personalización

- **Ruta de la librería local de footprints:**  
  Modifica la variable `LIBRARY_PATH` en `run_all.py` según la ubicación de tu librería de footprints.

- **Estructura del JSON de entrada:**  
  Asegúrate que `input.json` tenga el formato esperado por tu flujo.  
  Ejemplo mínimo:
  ```json
  {
    "components": [
      {
        "name": "R1",
        "footprint": "Resistor_SMD"
      },
      {
        "name": "C1",
        "footprint": "Capacitor_SMD"
      }
    ]
  }
  ```

---

## Preguntas Frecuentes

### ¿Puedo compartir el proyecto sin mi librería original?
**Sí.** Solo necesitas compartir la carpeta `output_project/` y KiCad encontrará todos los footprints usados.

### ¿Qué pasa si cambio la ubicación del proyecto?
No hay problema: las rutas en `resolved_input.json` son absolutas, pero puedes editarlo o adaptar el flujo para rutas relativas si lo prefieres.

### ¿Se pueden usar footprints personalizados?
Sí, siempre que estén en la librería local indicada y el script los pueda encontrar.

---

## Créditos

- Automatización y lógica: [Tú y tus colaboradores]
- Scripts de footprints: `footprint_validator/`
- Generador de PCB: `pcb_generator/`

---

## Licencia

[Elige la licencia que prefieras para tu proyecto]
