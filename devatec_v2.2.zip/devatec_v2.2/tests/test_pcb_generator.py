import os
import pytest
from pcb_generator.pcb_generator import generate_pcb
from pcb_generator.utils import mm_to_nm

def test_mm_to_nm():
    assert mm_to_nm(1.0) == 1000000
    assert mm_to_nm(0) == 0

def test_generate_pcb_runs(tmp_path):
    # Crea un input.json de ejemplo
    input_json = tmp_path / "input.json"
    output_pcb = tmp_path / "output.kicad_pcb"
    data = {
        "nets": ["GND", "VCC"],
        "components": [],
        "outline": {
            "type": "rect",
            "origin": [0, 0],
            "size": [10, 10]
        }
    }
    import json
    with open(input_json, "w") as f:
        json.dump(data, f)
    # Ejecuta generate_pcb (esto no debería lanzar excepción)
    generate_pcb(str(input_json), str(output_pcb))
    # Verifica que el archivo de salida se creó
    assert os.path.exists(output_pcb)