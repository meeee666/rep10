import os
import json
import shutil
from footprint_validator.footprint_matcher import find_best_footprint
from pcb_generator.pcb_generator import generate_pcb

LIBRARY_PATH = os.path.join(os.path.dirname(__file__), "footprints")
TOP_N = 1
INPUT_JSON = "input.json"
PROJECT_NAME = "output_project"
PROJECT_FOOTPRINTS = os.path.join(PROJECT_NAME, "footprints")
OUTPUT_PCB = os.path.join(PROJECT_NAME, "output.kicad_pcb")

def resolve_footprints(components, library_path, output_footprints_dir):
    resolved = {}
    os.makedirs(output_footprints_dir, exist_ok=True)
    for comp in components:
        name = comp["footprint"]
        matches = find_best_footprint(name, library_path, top_n=TOP_N)
        if matches:
            src = matches[0][1]
            if os.path.isfile(src):
                dest = os.path.join(output_footprints_dir, os.path.basename(src))
                shutil.copy2(src, dest)
                # Usar ruta relativa para KiCad
                resolved[name] = os.path.relpath(dest, os.path.dirname(OUTPUT_PCB))
        else:
            print(f"[ADVERTENCIA] Footprint no encontrado para: {name}")
    return resolved

def main():
    # Crea estructura de proyecto
    os.makedirs(PROJECT_NAME, exist_ok=True)
    os.makedirs(PROJECT_FOOTPRINTS, exist_ok=True)

    with open(INPUT_JSON, "r") as f:
        data = json.load(f)

    resolved = resolve_footprints(data["components"], LIBRARY_PATH, PROJECT_FOOTPRINTS)

    # Actualiza los componentes para usar rutas relativas de footprints
    for comp in data["components"]:
        name = comp["footprint"]
        if name in resolved:
            comp["footprint"] = resolved[name]
        else:
            print(f"[ADVERTENCIA] Footprint no encontrado para: {name}")

    # Guarda el JSON resuelto dentro del proyecto
    resolved_json_path = os.path.join(PROJECT_NAME, "resolved_input.json")
    with open(resolved_json_path, "w") as f:
        json.dump(data, f, indent=4)

    # Genera el PCB en la carpeta del proyecto
    generate_pcb(resolved_json_path, OUTPUT_PCB)
    print(f"[INFO] Proyecto generado en: {PROJECT_NAME}/")
    print(f"[INFO] Archivo PCB generado en: {OUTPUT_PCB}")
    print(f"[INFO] Footprints copiados en: {PROJECT_FOOTPRINTS}/")

if __name__ == "__main__":
    main()
