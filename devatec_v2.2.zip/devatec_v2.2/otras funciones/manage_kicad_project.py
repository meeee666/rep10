import os
import shutil
import json

# Configuración de rutas
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
RESOLVED_JSON = os.path.join(PROJECT_DIR, "output_project", "resolved_input.json")
FOOTPRINTS_LOCAL_DIR = os.path.join(PROJECT_DIR, "footprints_local")
GENERATED_DIR = os.path.join(PROJECT_DIR, "generated_files")

# Archivos generados típicos de KiCad
GENERATED_EXTENSIONS = [".kicad_pcb", ".kicad_prl", ".kicad_pro"]

def ensure_dir(d):
    if not os.path.exists(d):
        os.makedirs(d)

def copy_footprints(footprint_paths):
    ensure_dir(FOOTPRINTS_LOCAL_DIR)
    copied = []
    for fp_path in set(footprint_paths):
        if not os.path.isfile(fp_path):
            print(f"[ADVERTENCIA] No existe: {fp_path}")
            continue
        dest_path = os.path.join(FOOTPRINTS_LOCAL_DIR, os.path.basename(fp_path))
        shutil.copy(fp_path, dest_path)
        copied.append(dest_path)
        print(f"[INFO] Copiado: {fp_path} -> {dest_path}")
    return copied

def move_generated_files():
    ensure_dir(GENERATED_DIR)
    for f in os.listdir(PROJECT_DIR):
        for ext in GENERATED_EXTENSIONS:
            if f.endswith(ext):
                src = os.path.join(PROJECT_DIR, f)
                dst = os.path.join(GENERATED_DIR, f)
                shutil.move(src, dst)
                print(f"[INFO] Movido: {src} -> {dst}")

def main():
    # Leer el archivo RESOLVED_JSON que tiene rutas absolutas a los footprints correctos
    if not os.path.isfile(RESOLVED_JSON):
        print(f"[ERROR] No se encontró el archivo {RESOLVED_JSON}")
        return

    with open(RESOLVED_JSON, "r") as f:
        data = json.load(f)

    # Extraer rutas de footprints
    footprints_to_copy = [comp["footprint"] for comp in data["components"] if "footprint" in comp]
    print(f"[INFO] Footprints a copiar: {footprints_to_copy}")
    copy_footprints(footprints_to_copy)

    # Mover archivos generados a carpeta especial
    move_generated_files()
    print("[INFO] Proceso completo.")

if __name__ == "__main__":
    main()
