import os
import json
import shutil
import sys
import subprocess

# Añadir módulos al path
sys.path.append(os.path.join(os.path.dirname(__file__), "footprint_validator"))
sys.path.append(os.path.join(os.path.dirname(__file__), "pcb_generator"))

from footprint_matcher import find_best_footprint
from pcb_generator.pcb_generator import generate_pcb

# Opcional: importar función directamente
from preprocess_positions import apply_positions

# CONFIGURACIÓN DE RUTAS
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_JSON = os.path.join(PROJECT_DIR, "input.json")
OUTPUT_PROJECT_DIR = os.path.join(PROJECT_DIR, "output_project")
RESOLVED_JSON = os.path.join(OUTPUT_PROJECT_DIR, "resolved_input.json")
POSITIONS_JSON = os.path.join(OUTPUT_PROJECT_DIR, "resolved_positions.json")
FOOTPRINTS_LOCAL_DIR = os.path.join(OUTPUT_PROJECT_DIR, "footprints")
PCB_OUTPUT = os.path.join(OUTPUT_PROJECT_DIR, "output.kicad_pcb")

LIBRARY_PATH = "/home/agni-deva/Documentos/footprints"  # Cambia si tu librería local está en otro lugar
TOP_N = 1

def ensure_dir(d):
    if not os.path.exists(d):
        os.makedirs(d)

def resolve_footprints(components):
    resolved = {}
    for comp in components:
        name = comp["footprint"]
        matches = find_best_footprint(name, LIBRARY_PATH, top_n=TOP_N)
        if matches:
            resolved[name] = matches[0][1]
        else:
            print(f"[ADVERTENCIA] Footprint no encontrado para: {name}")
    return resolved

def copy_footprints(footprint_paths):
    ensure_dir(FOOTPRINTS_LOCAL_DIR)
    copied = {}
    for fp_path in set(footprint_paths):
        if not os.path.isfile(fp_path):
            print(f"[ADVERTENCIA] No existe: {fp_path}")
            continue
        dest_path = os.path.join(FOOTPRINTS_LOCAL_DIR, os.path.basename(fp_path))
        shutil.copy(fp_path, dest_path)
        copied[fp_path] = dest_path
        print(f"[INFO] Copiado: {fp_path} -> {dest_path}")
    return copied

def main():
    # 1. Leer el archivo JSON de entrada desde la raíz
    if not os.path.isfile(INPUT_JSON):
        print(f"[ERROR] No se encuentra {INPUT_JSON}")
        return

    with open(INPUT_JSON, "r") as f:
        data = json.load(f)

    # 2. Resolver rutas reales de footprints
    resolved = resolve_footprints(data["components"])

    # 3. Copiar footprints necesarios a la carpeta local del proyecto
    footprints_local_map = copy_footprints(resolved.values())

    # 4. Actualizar el JSON para que use la ruta local de cada footprint (output_project/footprints)
    for comp in data["components"]:
        orig_path = resolved.get(comp["footprint"])
        if orig_path and orig_path in footprints_local_map:
            comp["footprint"] = os.path.abspath(footprints_local_map[orig_path])
        else:
            print(f"[ADVERTENCIA] Footprint no copiado para: {comp['footprint']}")

    ensure_dir(OUTPUT_PROJECT_DIR)
    with open(RESOLVED_JSON, "w") as f:
        json.dump(data, f, indent=4)
    print(f"[INFO] JSON actualizado guardado en: {RESOLVED_JSON}")

    # 5. Asignar posiciones usando plantillas
    # Opción A: Llamar como script externo (menos eficiente)
    # subprocess.run(["python3", "preprocess_positions.py", RESOLVED_JSON, POSITIONS_JSON], check=True)
    # Opción B: Llamar la función directamente (mejor)
    apply_positions(RESOLVED_JSON, POSITIONS_JSON)

    # 6. Generar el PCB usando el JSON con posiciones
    generate_pcb(POSITIONS_JSON, PCB_OUTPUT)
    print(f"[INFO] PCB generado en: {PCB_OUTPUT}")

if __name__ == "__main__":
    main()
