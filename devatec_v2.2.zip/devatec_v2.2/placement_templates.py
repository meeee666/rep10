import math

def place_circle(center, radius, count, start_angle=0, end_angle=360, direction="ccw"):
    if count == 1:
        return [center]
    a0 = math.radians(start_angle)
    a1 = math.radians(end_angle)
    if direction == "ccw":
        if a1 <= a0:
            a1 += 2*math.pi
        angle_span = a1 - a0
    else:
        if a1 >= a0:
            a1 -= 2*math.pi
        angle_span = a1 - a0
    steps = count - 1 if count > 1 else 1
    positions = []
    for i in range(count):
        alpha = a0 + (angle_span * i / steps)
        x = center[0] + radius * math.cos(alpha)
        y = center[1] + radius * math.sin(alpha)
        positions.append([round(x,4), round(y,4)])
    return positions

def place_column(x, y_start, y_end, count, direction="down"):
    if count == 1:
        return [[x, (y_start + y_end) / 2.0]]
    step = (y_end - y_start) / (count - 1)
    positions = []
    for i in range(count):
        y = y_start + step * i
        positions.append([x, y])
    if direction == "up":
        positions = positions[::-1]
    return positions

def place_row(y, x_start, x_end, count, direction="right"):
    if count == 1:
        return [[(x_start + x_end) / 2.0, y]]
    step = (x_end - x_start) / (count - 1)
    positions = []
    for i in range(count):
        x = x_start + step * i
        positions.append([x, y])
    if direction == "left":
        positions = positions[::-1]
    return positions

def place_center(board_width, board_height):
    return [board_width/2.0, board_height/2.0]

def place_edge(board_width, board_height, side, offset=5, along="y", pos=None):
    if side == "left":
        x = offset
        y = pos if pos is not None else board_height/2.0
        return [x, y]
    elif side == "right":
        x = board_width - offset
        y = pos if pos is not None else board_height/2.0
        return [x, y]
    elif side == "top":
        x = pos if pos is not None else board_width/2.0
        y = board_height - offset
        return [x, y]
    elif side == "bottom":
        x = pos if pos is not None else board_width/2.0
        y = offset
        return [x, y]
    else:
        raise ValueError("Unknown side for place_edge")
