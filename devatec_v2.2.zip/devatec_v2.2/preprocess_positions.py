import json
from placement_templates import place_circle, place_column, place_row, place_center, place_edge

def apply_positions(input_json_path, output_json_path):
    with open(input_json_path, "r") as f:
        data = json.load(f)

    instructions = data["project_instructions"]
    width = instructions["edge_cuts"]["width"]
    height = instructions["edge_cuts"]["height"]

    # Map ref -> component entry
    ref_to_comp = {c["ref"]: c for c in data["components"]}

    # Para cada plantilla declarada en project_instructions
    for placement in instructions.get("component_placement", []):
        if placement.get("type") == "rotary_encoder":
            pos = placement.get("position", place_center(width, height))
            # Si es dict con 'x' y 'y', conviértelo a lista [x, y]
            if isinstance(pos, dict) and "x" in pos and "y" in pos:
                pos = [pos["x"], pos["y"]]
            ref = placement["ref"]
            ref_to_comp[ref]["position"] = pos

        elif placement.get("pattern") == "circle":
            count = len(placement["refs"])
            pos_list = place_circle(
                center=[placement["placement"]["center"]["x"], placement["placement"]["center"]["y"]],
                radius=placement["placement"]["radius"],
                count=count,
                start_angle=placement["placement"].get("start_angle", 0),
                end_angle=placement["placement"].get("end_angle", 360),
                direction=placement["placement"].get("direction", "ccw")
            )
            for ref, pos in zip(placement["refs"], pos_list):
                ref_to_comp[ref]["position"] = pos

        elif placement.get("pattern") == "column":
            count = len(placement["refs"])
            pos_list = place_column(
                x=placement["placement"]["x"],
                y_start=placement["placement"]["start_y"],
                y_end=placement["placement"]["end_y"],
                count=count,
                direction="down"
            )
            for ref, pos in zip(placement["refs"], pos_list):
                ref_to_comp[ref]["position"] = pos

        elif placement.get("type") == "pinheader":
            pos = place_edge(
                board_width=width,
                board_height=height,
                side=placement["placement"].get("side", "left"),
                offset=placement["placement"].get("distance_from_edge", 5),
                along="y",
                pos=placement["placement"].get("y", height/2.0)
            )
            # Si es dict con 'x' y 'y', conviértelo a lista [x, y]
            if isinstance(pos, dict) and "x" in pos and "y" in pos:
                pos = [pos["x"], pos["y"]]
            ref = placement["ref"]
            ref_to_comp[ref]["position"] = pos

        # Puedes agregar más patrones aquí (row, grid, etc)

    # Asignar posición por defecto a los componentes sin posición
    faltantes = [comp for comp in data["components"] if "position" not in comp]
    if faltantes:
        print("[ADVERTENCIA] Los siguientes componentes no tienen posición asignada, se colocarán en (0,0):",
              [c["ref"] for c in faltantes])
        for i, comp in enumerate(faltantes):
            comp["position"] = [0, 0]

    # Guarda el nuevo JSON con posiciones
    with open(output_json_path, "w") as f:
        json.dump(data, f, indent=2)
    print(f"[INFO] Posiciones asignadas y guardadas en: {output_json_path}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 3:
        print("Uso: python3 preprocess_positions.py input.json output.json")
    else:
        apply_positions(sys.argv[1], sys.argv[2])
