def mm_to_nm(val_mm):
    """Convierte milímetros a nanómetros para KiCad."""
    return int(val_mm * 1e6)