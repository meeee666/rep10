import pcbnew
import json
import sys
import os

def mm_to_nm(val_mm):
    return int(val_mm * 1e6)

def main(input_file, output_pcb):
    with open(input_file, "r") as f:
        data = json.load(f)

    board = pcbnew.BOARD()

    # Crear redes
    netcodes = {}
    for i, netname in enumerate(data["nets"]):
        net = pcbnew.NETINFO_ITEM(board, netname)
        board.Add(net)
        netcodes[netname] = net

    # Añadir footprints
    for comp in data["components"]:
        footprint_path = comp["footprint"]
        if not os.path.isfile(footprint_path):
            print(f"Archivo de footprint no encontrado: {footprint_path}")
            continue

        lib_path = os.path.dirname(footprint_path)
        footprint_name = os.path.splitext(os.path.basename(footprint_path))[0]

        footprint = pcbnew.FootprintLoad(lib_path, footprint_name)
        if not footprint:
            print(f"Error cargando footprint desde: {lib_path} / {footprint_name}")
            continue

        footprint.SetReference(comp["reference"])
        x, y = comp["position"]
        footprint.SetPosition(pcbnew.VECTOR2I(mm_to_nm(x), mm_to_nm(y)))

        for pad in footprint.Pads():
            pinname = pad.GetName()
            netname = comp.get("pins", {}).get(pinname)
            if netname and netname in netcodes:
                pad.SetNet(netcodes[netname])

        board.Add(footprint)

    # Dibujar contorno Edge.Cuts
    outline = data.get("outline", {})
    rect_pts = []
    if outline.get("type") == "rect":
        ox, oy = outline["origin"]
        w, h = outline["size"]
        rect_pts = [
            ((ox, oy), (ox + w, oy)),
            ((ox + w, oy), (ox + w, oy + h)),
            ((ox + w, oy + h), (ox, oy + h)),
            ((ox, oy + h), (ox, oy)),
        ]
        for start, end in rect_pts:
            edge = pcbnew.PCB_SHAPE(board)
            edge.SetShape(pcbnew.SHAPE_T_SEGMENT)
            edge.SetLayer(pcbnew.Edge_Cuts)
            edge.SetStart(pcbnew.VECTOR2I(mm_to_nm(start[0]), mm_to_nm(start[1])))
            edge.SetEnd(pcbnew.VECTOR2I(mm_to_nm(end[0]), mm_to_nm(end[1])))
            board.Add(edge)

    # Agregar zonas
    for zone in data.get("zones", []):
        layer = pcbnew.F_Cu if zone["layer"] == "F.Cu" else pcbnew.B_Cu
        netname = zone["net"]
        if netname not in netcodes:
            print(f"Net '{netname}' no encontrada para la zona.")
            continue

        zone_container = pcbnew.ZONE(board)
        zone_container.SetLayer(layer)
        zone_container.SetNetCode(netcodes[netname].GetNetCode())
        zone_container.SetLocalClearance(0)
        zone_container.SetIsFilled(True)

        poly = zone_container.Outline()
        poly.NewOutline()
        ox, oy = outline["origin"]
        w, h = outline["size"]
        for corner in [(ox, oy), (ox + w, oy), (ox + w, oy + h), (ox, oy + h)]:
            poly.Append(pcbnew.VECTOR2I(mm_to_nm(corner[0]), mm_to_nm(corner[1])))

        board.Add(zone_container)

    board.Save(output_pcb)
    print(f"Archivo PCB guardado en: {output_pcb}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Uso: python3 pcb_generator.py input.json output.kicad_pcb")
    else:
        main(sys.argv[1], sys.argv[2])
