#!/usr/bin/env python3
"""Resuelve posiciones de componentes según reglas declarativas.

Añadido en esta versión:
- Completa automáticamente la ruta de los footprints añadiendo el prefijo 'footprints/' en caso de ser relativo.
"""

import json
from pathlib import Path

def resolve_positions(data):
    comps = {c["reference"]: c for c in data["components"]}
    assigned = {}

    for inst in data.get("placement_instructions", []):
        pattern = inst["pattern"]

        if pattern == "row":
            x_start, y_start = inst["start"]
            pitch = inst.get("pitch", 10)
            for idx, ref in enumerate(inst["refs"]):
                assigned[ref] = [x_start + idx * pitch, y_start]

        elif pattern == "below":
            ref_above = inst["ref"]
            offset_y = inst.get("offset_y", 10)
            if ref_above in comps:
                x_above, y_above = comps[ref_above].get("position", (0, 0))
                for ref in inst["refs"]:
                    assigned[ref] = [x_above, y_above + offset_y]

        # Otras reglas de ejemplo (expandir según necesidad)

    # Aplicar posiciones resultantes
    outline = data.get("board", {}).get("edge_cuts", {})
    w, h = (outline.get("size") or (100, 100))

    for comp in data["components"]:
        ref = comp["reference"]
        comp["position"] = assigned.get(ref, [w / 2, h / 2])

        # Normalizar ruta de footprint
        fp = comp.get("footprint", "")
        if fp and not fp.startswith("footprints/"):
            comp["footprint"] = f"footprints/{fp}"

    return data

def main():
    input_path = Path("instruccion.json")
    output_path = Path("resolved_input.json")

    data = json.loads(input_path.read_text())
    resolved = resolve_positions(data)
    output_path.write_text(json.dumps(resolved, indent=2))
    print("[OK] resolved_input.json generado")

if __name__ == "__main__":
    main()
