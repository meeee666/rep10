# build_instruction.py

import json
import os
import sys
from pathlib import Path

# Footprints válidos que tú ya tienes en tu librería local
VALID_FOOTPRINTS = [
    "footprints/Rotary_Encoder.pretty/RotaryEncoder_Alps_EC11E-Switch_Vertical_H20mm.kicad_mod",
    "footprints/WS2812-2020.pretty/LED_WS2812-2020.kicad_mod",
    "footprints/Connector_PinHeader_2.54mm.pretty/PinHeader_1x09_P2.54mm_Vertical.kicad_mod"
]

DEFAULT_THERMAL_GAP = 0.5
DEFAULT_MIN_THICKNESS = 0.25

def validate_json(data):
    errors = []

    # Validar EDGE_CUTS
    if "board" not in data or "edge_cuts" not in data["board"]:
        errors.append("❌ Falta 'board.edge_cuts'")
    else:
        ec = data["board"]["edge_cuts"]
        for k in ["x", "y", "width", "height"]:
            if k not in ec:
                errors.append(f"❌ 'board.edge_cuts' no tiene campo '{k}'")

    # Validar COMPONENTES
    component_refs = set()
    for comp in data.get("components", []):
        ref = comp.get("ref")
        fp = comp.get("footprint")
        if not ref or not fp:
            errors.append(f"❌ Componente inválido: {comp}")
        else:
            component_refs.add(ref)
            if fp not in VALID_FOOTPRINTS:
                errors.append(f"❌ Footprint desconocido: {fp}")

    # Validar POSICIONES
    for pos in data.get("positions", []):
        if pos["ref"] not in component_refs:
            errors.append(f"❌ Posición para componente inexistente: {pos['ref']}")

    # Validar NETS
    for net in data.get("nets", []):
        for pin in net.get("pins", []):
            if ":" not in pin:
                errors.append(f"❌ Formato de pin inválido: {pin}")
            else:
                ref, _ = pin.split(":")
                if ref not in component_refs:
                    errors.append(f"❌ Pin refiere a componente inexistente: {ref}")

    return errors

def fill_defaults(data):
    # Asegurar thermal_gap y min_thickness en zonas
    for zone in data.get("board", {}).get("zones", []):
        zone.setdefault("thermal_gap", DEFAULT_THERMAL_GAP)
        zone.setdefault("min_thickness", DEFAULT_MIN_THICKNESS)

    return data

def main(input_file, output_file="instruccion.json"):
    with open(input_file, "r") as f:
        data = json.load(f)

    errors = validate_json(data)
    if errors:
        print("\n🚫 Errores encontrados en el archivo:")
        for e in errors:
            print("  -", e)
        print("\nCorrige los errores antes de generar el JSON.")
        sys.exit(1)

    # Autocompletado de campos si aplica
    data = fill_defaults(data)

    # Guardar archivo válido
    with open(output_file, "w") as f:
        json.dump(data, f, indent=2)
    
    print(f"\n✅ Archivo generado correctamente: {output_file}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Uso: python3 build_instruction.py entrada.json [salida.json]")
        sys.exit(1)

    entrada = sys.argv[1]
    salida = sys.argv[2] if len(sys.argv) > 2 else "instruccion.json"
    main(entrada, salida)

