#!/usr/bin/env python3
"""Wrapper script: preprocess -> footprint resolution -> PCB generation.

Improvements:
- Ensures output_project directory exists before invoking pcb_generator.
- Passes absolute/clean path to the generator.
- Exits with non‑zero status if pcb_generator did not actually produce the file.
"""

import subprocess
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
OUTPUT_DIR = BASE / "output_project"
OUTPUT_DIR.mkdir(exist_ok=True)

def run_step(cmd, desc):
    print(f"[INFO] {desc}...")
    res = subprocess.run(cmd)
    if res.returncode != 0:
        print(f"[ERROR] Paso fallido: {desc} (código {res.returncode})")
        sys.exit(res.returncode)

# 1. Calcular posiciones
run_step([sys.executable, str(BASE / "preprocess_positions.py")],
         "Preprocesando posiciones")
print("[OK] resolved_input.json generado")

# 2. Validar footprints
run_step([sys.executable, str(BASE / "footprint_validator" / "footprint_matcher.py")],
         "Validando footprints")

# 2b. Resolver y copiar footprints locales
run_step([sys.executable, str(BASE / "footprint_validator" / "resolve_and_copy_footprints.py")],
         "Resolviendo y copiando footprints al proyecto")

# 3. Generar PCB
output_pcb = OUTPUT_DIR / "board.kicad_pcb"
run_step([sys.executable, str(BASE / "pcb_generator" / "pcb_generator.py"),
          str(BASE / "resolved_input.json"),
          str(output_pcb)],
         "Generando archivos de PCB")

if not output_pcb.exists():
    print(f"[ERROR] pcb_generator finalizó pero no se creó {output_pcb}")
    sys.exit(1)

print(f"[OK] Archivo PCB generado en: {output_pcb}")
