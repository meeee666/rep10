import json
import os
from pathlib import Path
from footprint_matcher import find_best_footprint

# Carpeta(s) donde buscar
FOOTPRINT_LIB_PATHS = [
    "/home/agni-deva/Documentos/footprints",  # Cambia esto por la ruta real donde tienes los .kicad_mod
    # puedes agregar más rutas si tienes otras bibliotecas
]

def assign_footprints(input_json, output_json):
    data = json.loads(Path(input_json).read_text())
    changed = False

    for comp in data["components"]:
        orig_fp = comp["footprint"]
        library = orig_fp.split('/')[0]
        basename = os.path.basename(orig_fp)
        best_fp = None

        for lib_path in FOOTPRINT_LIB_PATHS:
            lib_dir = os.path.join(lib_path, library)
            if os.path.isdir(lib_dir):
                matches = find_best_footprint(basename, lib_dir, top_n=1)
                if matches:
                    _, best_fp_path = matches[0]
                    comp["footprint"] = best_fp_path
                    changed = True
                    break
        
        if not changed:
            print(f"[ADVERTENCIA] No se encontró el footprint para {comp['reference']} - {orig_fp}")

    Path(output_json).write_text(json.dumps(data, indent=2))
    print("[OK] Footprints asignados en", output_json)

if __name__ == "__main__":
    assign_footprints("resolved_input.json", "resolved_input.json")
