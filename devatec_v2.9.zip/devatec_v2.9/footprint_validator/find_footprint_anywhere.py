import os

def find_footprint_anywhere(footprint_filename, footprints_root):
    """
    Busca un archivo de footprint por nombre en toda la jerarquía de footprints_root.
    Devuelve la ruta completa si lo encuentra, si no, None.
    """
    for root, dirs, files in os.walk(footprints_root):
        for file in files:
            if file.lower() == footprint_filename.lower():
                return os.path.join(root, file)
    return None
