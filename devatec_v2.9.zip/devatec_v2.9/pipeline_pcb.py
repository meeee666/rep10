#!/usr/bin/env python3
"""
pipeline_pcb.py
===============

Uso:
    python3 pipeline_pcb.py [--raw RAW_JSON] [--dst INSTRUCCION_JSON] [--skip-run]

• RAW_JSON  : archivo JSON bruto salido del asistente (default: datos_gpt.json)
• INSTRUCCION_JSON : nombre del JSON limpio a generar (default: instruccion.json)
• --skip-run : valida y genera el JSON, pero NO ejecuta run_all.py
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path

# 1️⃣  AJUSTA ESTA LISTA CON TUS FOOTPRINTS PERMITIDOS
VALID_FOOTPRINTS = {
    "footprints/Rotary_Encoder.pretty/RotaryEncoder_Alps_EC11E-Switch_Vertical_H20mm.kicad_mod",
    "footprints/WS2812-2020.pretty/LED_WS2812-2020.kicad_mod",
    "footprints/Connector_PinHeader_2.54mm.pretty/PinHeader_1x09_P2.54mm_Vertical.kicad_mod",
}

DEFAULT_THERMAL_GAP = 0.5   # mm
DEFAULT_MIN_THICKNESS = 0.25  # mm


# ────────────────────────────────────────────────────────────────────────────────
# VALIDACIÓN
# ────────────────────────────────────────────────────────────────────────────────
def validate_and_complete(data: dict):
    """Devuelve (errors:list[str], fixed_data:dict)."""
    errors = []

    # Board / edge_cuts ---------------------------------------------------------
    board = data.get("board")
    if not board or "edge_cuts" not in board:
        errors.append("Falta la sección 'board.edge_cuts'.")
    else:
        ec = board["edge_cuts"]
        for k in ("x", "y", "width", "height"):
            if k not in ec:
                errors.append(f"'edge_cuts' sin campo obligatorio '{k}'.")

    # Components ----------------------------------------------------------------
    comps = data.get("components", [])
    refs = {c.get("ref") for c in comps if c.get("ref")}
    for c in comps:
        if "ref" not in c or "footprint" not in c:
            errors.append(f"Componente incompleto: {c}")
        elif c["footprint"] not in VALID_FOOTPRINTS:
            errors.append(f"Footprint no reconocido: {c['footprint']}")

    # Positions -----------------------------------------------------------------
    for p in data.get("positions", []):
        if p.get("ref") not in refs:
            errors.append(f"Posición hace referencia a componente inexistente: {p}")

    # Nets ----------------------------------------------------------------------
    for net in data.get("nets", []):
        for pin in net.get("pins", []):
            if ":" not in pin:
                errors.append(f"Pin con formato inválido (falta ':'): {pin}")
            else:
                ref, _ = pin.split(":", 1)
                if ref not in refs:
                    errors.append(f"Pin '{pin}' alude a componente inexistente.")

    # Defaults zonas ------------------------------------------------------------
    for zone in board.get("zones", []) if board else []:
        zone.setdefault("thermal_gap", DEFAULT_THERMAL_GAP)
        zone.setdefault("min_thickness", DEFAULT_MIN_THICKNESS)

    return errors, data


# ────────────────────────────────────────────────────────────────────────────────
# RUNNER KiCad
# ────────────────────────────────────────────────────────────────────────────────
def run_kicad_flow():
    """Ejecuta run_all.py y retransmite su salida."""
    print("🔧  Ejecutando run_all.py …")
    result = subprocess.run([sys.executable, "run_all.py"])
    if result.returncode == 0:
        print("✅  PCB generado correctamente (ver ./output_project/).")
    else:
        sys.exit("❌  run_all.py terminó con errores.")


# ────────────────────────────────────────────────────────────────────────────────
# MAIN
# ────────────────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Valida JSON y genera PCB.")
    parser.add_argument("--raw", default="datos_gpt.json",
                        help="Archivo JSON crudo del asistente.")
    parser.add_argument("--dst", default="instruccion.json",
                        help="Archivo JSON limpio que se generará.")
    parser.add_argument("--skip-run", action="store_true",
                        help="Solo valida y genera JSON; no ejecuta run_all.py.")
    args = parser.parse_args()

    raw_path = Path(args.raw)
    if not raw_path.is_file():
        sys.exit(f"❌  No se encontró el archivo {raw_path}")

    # Leer JSON crudo
    try:
        data = json.loads(raw_path.read_text())
    except json.JSONDecodeError as e:
        sys.exit(f"❌  JSON inválido: {e}")

    # Validar + completar defaults
    errs, fixed = validate_and_complete(data)
    if errs:
        print("🚫  Se encontraron errores en el JSON:")
        for e in errs:
            print("   -", e)
        sys.exit("Arregla el archivo y vuelve a ejecutar.")

    # Guardar JSON final
    dst_path = Path(args.dst)
    dst_path.write_text(json.dumps(fixed, indent=2))
    print(f"✅  Archivo {dst_path} generado sin problemas.")

    # Lanzar flujo KiCad si procede
    if not args.skip_run:
        run_kicad_flow()


if __name__ == "__main__":
    main()

