#!/usr/bin/env python3
"""Genera un archivo .kicad_pcb a partir de un JSON de instrucción.

Cambios principales:
- Compatible con el esquema actual: datos['board']['edge_cuts'] y datos['board']['zones'].
- Acepta el esquema legacy basado en datos['outline'] / datos['zones'].
- Crea el directorio de salida si no existe.
- Valida rutas de footprint y reporta de forma centrada.
- Añade fillet opcional de radio especificado.
"""

import json
import os
import sys
from pathlib import Path

import pcbnew

def mm_to_nm(mm):
    """Convierte milímetros a nanómetros (unidad interna de KiCad)."""
    return int(float(mm) * 1e6)

def build_board(data):
    board = pcbnew.BOARD()

    # === 1. Nets =========================================================
    netcodes = {}
    for netname in data.get("nets", []):
        net = pcbnew.NETINFO_ITEM(board, netname)
        board.Add(net)
        netcodes[netname] = net

    # === 2. Footprints ====================================================
    for comp in data.get("components", []):
        fp_path = comp.get("footprint", "")
        if not fp_path:
            print(f"[WARN] {comp['reference']}: sin footprint definido")
            continue

        # Resolución relativa: si no es ruta absoluta, resuélvela desde cwd
        fp_path = Path(fp_path)
        if not fp_path.is_absolute():
            fp_path = Path.cwd() / fp_path

        if not fp_path.is_file():
            print(f"[WARN] {comp['reference']}: Footprint no encontrado -> {fp_path}")
            continue

        lib_dir = str(fp_path.parent)
        fp_name = fp_path.stem  # sin extensión

        footprint = pcbnew.FootprintLoad(lib_dir, fp_name)
        if not footprint:
            print(f"[WARN] {comp['reference']}: error cargando footprint {fp_name}")
            continue

        footprint.SetReference(comp['reference'])

        # Colocación
        x_mm, y_mm = comp.get("position", (0, 0))
        footprint.SetPosition(pcbnew.VECTOR2I(mm_to_nm(x_mm), mm_to_nm(y_mm)))
        rotation = comp.get("rotation", 0)
        footprint.SetOrientationDegrees(rotation)

        # Asignación de nets a pads
        for pad in footprint.Pads():
            pin = pad.GetName()
            net_name = comp.get("pins", {}).get(pin)
            if net_name and net_name in netcodes:
                pad.SetNet(netcodes[net_name])

        board.Add(footprint)

    # === 3. Borde de la PCB  =============================================
    board_cfg = data.get("board", {})
    outline = (data.get("outline") or
               board_cfg.get("edge_cuts") or
               {})

    if outline.get("shape") == "rect":
        ox, oy = outline["origin"]
        w, h = outline["size"]
        corners = [
            ((ox, oy), (ox + w, oy)),
            ((ox + w, oy), (ox + w, oy + h)),
            ((ox + w, oy + h), (ox, oy + h)),
            ((ox, oy + h), (ox, oy)),
        ]
        for start, end in corners:
            edge = pcbnew.PCB_SHAPE(board)
            edge.SetShape(pcbnew.SHAPE_T_SEGMENT)
            edge.SetLayer(pcbnew.Edge_Cuts)
            edge.SetStart(pcbnew.VECTOR2I(mm_to_nm(start[0]), mm_to_nm(start[1])))
            edge.SetEnd(pcbnew.VECTOR2I(mm_to_nm(end[0]), mm_to_nm(end[1])))
            board.Add(edge)

    # === 4. Zonas (polígonos de cobre) ===================================
    zones = data.get("zones") or board_cfg.get("zones", [])
    if zones and not outline:
        print("[WARN] Hay zonas pero no outline para referenciar su contorno.")

    for zone_def in zones:
        layer = pcbnew.F_Cu if zone_def["layer"] == "F.Cu" else pcbnew.B_Cu
        net_name = zone_def["net"]
        if net_name not in netcodes:
            print(f"[WARN] Net {net_name} no definida; omitiendo zona.")
            continue

        zone = pcbnew.ZONE(board)
        zone.SetLayer(layer)
        zone.SetNetCode(netcodes[net_name].GetNetCode())
        # Configure thermal gap and minimum thickness with compatibility across KiCad versions
        thermal_gap_nm = mm_to_nm(zone_def.get("thermal_gap", 0.5))
        min_thickness_nm = mm_to_nm(zone_def.get("min_thickness", 0.25))

        if hasattr(zone, "SetThermalGap"):
            zone.SetThermalGap(thermal_gap_nm)
        elif hasattr(zone, "SetThermalReliefGap"):
            zone.SetThermalReliefGap(thermal_gap_nm)

        if hasattr(zone, "SetMinThickness"):
            zone.SetMinThickness(min_thickness_nm)
        elif hasattr(zone, "SetZoneMinThickness"):
            zone.SetZoneMinThickness(min_thickness_nm)

        zone.SetIsFilled(True)

        poly = zone.Outline()
        poly.NewOutline()

        if outline:
            ox, oy = outline["origin"]
            w, h = outline["size"]
            for cx, cy in [(ox, oy),
                           (ox + w, oy),
                           (ox + w, oy + h),
                           (ox, oy + h)]:
                poly.Append(pcbnew.VECTOR2I(mm_to_nm(cx), mm_to_nm(cy)))
        else:
            # fallback simple: cuadrado de 50x50 mm
            for cx, cy in [(0, 0), (50, 0), (50, 50), (0, 50)]:
                poly.Append(pcbnew.VECTOR2I(mm_to_nm(cx), mm_to_nm(cy)))

        board.Add(zone)

    return board

def main(json_in: str, pcb_out: str):
    pcb_out = Path(pcb_out)
    pcb_out.parent.mkdir(parents=True, exist_ok=True)

    with open(json_in, "r") as f:
        data = json.load(f)

    board = build_board(data)
    board.Save(str(pcb_out))
    print(f"[OK] Archivo PCB guardado en {pcb_out}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Uso: python3 pcb_generator.py <instruccion_resuelta.json> <salida.kicad_pcb>")
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
