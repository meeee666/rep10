import os
import json
import sys

# Agregar paths relativos para importar los módulos
sys.path.append(os.path.join(os.path.dirname(__file__), "footprint_validator"))
sys.path.append(os.path.join(os.path.dirname(__file__), "pcb_generator"))

from footprint_matcher import find_best_footprint
from pcb_generator import main as generate_pcb

# Configuración
LIBRARY_PATH = "/home/agni-deva/Documentos/footprints"  # Cambiar a la ruta real de tus footprints
TOP_N = 1
INPUT_JSON = "input.json"
OUTPUT_PCB = "output.kicad_pcb"

def resolve_footprints(components):
    resolved = {}
    for comp in components:
        name = comp["footprint"]
        matches = find_best_footprint(name, LIBRARY_PATH, top_n=TOP_N)
        if matches:
            resolved[name] = matches[0][1]  # Seleccionamos la mejor coincidencia
    return resolved

def main():
    # Leer el archivo JSON
    with open(os.path.join("pcb_generator", INPUT_JSON), "r") as f:
        data = json.load(f)

    # Resolver footprints
    resolved = resolve_footprints(data["components"])

    # Insertar rutas resueltas en los componentes
    for comp in data["components"]:
        name = comp["footprint"]
        if name in resolved:
            comp["footprint"] = resolved[name]
        else:
            print(f"[ADVERTENCIA] Footprint no encontrado para: {name}")

    # Guardar JSON temporal con rutas absolutas
    resolved_json_path = os.path.join("pcb_generator", "resolved_input.json")
    with open(resolved_json_path, "w") as f:
        json.dump(data, f, indent=4)

    # Generar archivo .kicad_pcb
    generate_pcb(resolved_json_path, OUTPUT_PCB)
    print(f"[INFO] Archivo PCB generado en: {OUTPUT_PCB}")

if __name__ == "__main__":
    main()
