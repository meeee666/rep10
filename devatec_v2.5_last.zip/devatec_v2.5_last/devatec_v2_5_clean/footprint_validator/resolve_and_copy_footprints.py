import sys
import os
sys.path.append(os.path.dirname(__file__))
from find_footprint_anywhere import find_footprint_anywhere

import json
import shutil
from pathlib import Path

FOOTPRINTS_ROOT = "/home/agni-deva/Documentos/footprints"
PROJ_FOOTPRINTS_DIR = Path(__file__).parent.parent / "footprints"

def resolve_and_copy(input_json, output_json):
    data = json.loads(Path(input_json).read_text())
    for comp in data["components"]:
        orig_fp = comp["footprint"]
        fp_filename = os.path.basename(orig_fp)
        found = False

        match_path = find_footprint_anywhere(fp_filename, FOOTPRINTS_ROOT)
        if match_path:
            rel_pretty = Path(match_path).parent.name
            dest_dir = PROJ_FOOTPRINTS_DIR / rel_pretty
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest_path = dest_dir / fp_filename
            shutil.copy2(match_path, dest_path)
            comp["footprint"] = str(dest_path.relative_to(Path.cwd()))
            found = True
            print(f"[OK] {comp['reference']} -> {dest_path}")
        else:
            print(f"[ADVERTENCIA] No se encontró el footprint para {comp['reference']} - {orig_fp}")

    Path(output_json).write_text(json.dumps(data, indent=2))
    print("[OK] Footprints resueltos y copiados en", output_json)

if __name__ == "__main__":
    resolve_and_copy("resolved_input.json", "resolved_input.json")
