
import json
from pathlib import Path

def resolve_positions(data):
    comps = {c["reference"]: c for c in data["components"]}
    pos = {}

    for inst in data.get("placement_instructions", []):
        if inst["pattern"] == "row":
            x, y = inst["start"]
            pitch = inst.get("pitch", 10)
            for i, ref in enumerate(inst["refs"]):
                pos[ref] = [x + i * pitch, y]
        elif inst["pattern"] == "below":
            dy = inst.get("offset_y", 10)
            for tgt, ref in zip(inst["target_refs"], inst["refs"]):
                if tgt in pos:
                    pos[ref] = [pos[tgt][0], pos[tgt][1] + dy]

    # Asignar posiciones finales con fallback al centro
    w, h = data["board"]["edge_cuts"]["size"]
    for c in data["components"]:
        ref = c["reference"]
        c["position"] = pos.get(ref, [w / 2, h / 2])

    return data

if __name__ == "__main__":
    input_path = Path("instruccion.json")
    output_path = Path("resolved_input.json")

    data = json.loads(input_path.read_text())
    resolved = resolve_positions(data)
    output_path.write_text(json.dumps(resolved, indent=2))
    print("[OK] resolved_input.json generado")
