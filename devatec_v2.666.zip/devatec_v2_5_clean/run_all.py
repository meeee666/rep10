import subprocess
import sys
from pathlib import Path

BASE = Path(__file__).parent

print("[INFO] Paso 1: Preprocesando posiciones...")
subprocess.run([sys.executable, str(BASE / "preprocess_positions.py")], check=True)
print("[OK] resolved_input.json generado")

print("[INFO] Paso 2: Validando footprints...")
subprocess.run([sys.executable, str(BASE / "footprint_validator" / "footprint_matcher.py")], check=True)

print("[INFO] Paso 2b: Resolviendo y copiando footprints al proyecto...")
subprocess.run([sys.executable, str(BASE / "footprint_validator" / "resolve_and_copy_footprints.py")], check=True)

print("[INFO] Paso 3: Generando archivos de PCB...")
subprocess.run([sys.executable, str(BASE / "pcb_generator" / "pcb_generator.py"), 
                str(BASE / "resolved_input.json"),
                str(BASE / "output_project" / "board.kicad_pcb")], check=True)
print("[OK] Archivo PCB generado: output_project/board.kicad_pcb")
